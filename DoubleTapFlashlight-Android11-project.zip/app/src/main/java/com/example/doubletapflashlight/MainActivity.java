package com.example.doubletapflashlight;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(40,50,40,40);
        TextView title=new TextView(this); title.setText("Double Tap Flashlight"); title.setTextSize(26); title.setTextColor(Color.BLACK);
        status=new TextView(this); status.setTextSize(17); status.setPadding(0,30,0,30);
        Button overlay=new Button(this); overlay.setText("১. Overlay permission দিন");
        Button start=new Button(this); start.setText("২. সার্ভিস চালু করুন");
        l.addView(title); l.addView(status); l.addView(overlay); l.addView(start); setContentView(l);
        overlay.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:"+getPackageName())));
        });
        start.setOnClickListener(v -> {
            Intent i=new Intent(this,TapService.class);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            status.setText("চালু হয়েছে। হোমস্ক্রিন/লকস্ক্রিনে দুইবার দ্রুত ট্যাপ করে টর্চ টগল করার চেষ্টা করুন।");
        });
        status.setText("নোট: স্ক্রিন পুরো OFF/ফোন power-off অবস্থায় সামনের স্ক্রিনে ট্যাপ শনাক্ত করা সম্ভব নয়।");
    }
}
